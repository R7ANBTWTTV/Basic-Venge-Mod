pc.app.on("Map:Loaded", () => {
  setTimeout(() => {
    if (pc.currentMap == "Sierra") {
      pc.app.renderer.scene.exposure = 1.6
      pc.app.renderer.scene.skyboxIntensity = 0.8
      pc.app.root.findByName("Light").light.color = {
        r: 0.5,
        g: 0.4,
        b: 0.4,
        a: 1,
      };
    }
if (pc.currentMap == "Mistle") {
      pc.app.renderer.scene.exposure = 1.6
      pc.app.renderer.scene.skyboxIntensity = 1
      pc.app.root.findByName("Light").light.color = {
        r: 0.6,
        g: 0.5,
        b: 0.5,
        a: 1,
      };
    }
    if (pc.currentMap == "Xibalba") {
    pc.app.renderer.scene.exposure = 4
      pc.app.renderer.scene.skyboxIntensity = 0.05
      pc.app.root.findByName("Light").light.color = {
        r: 0.6,
        g: 0.5,
        b: 0.5,
        a: 1,
      };
    }
    if (pc.currentMap == "Tundra") {
    pc.app.renderer.scene.exposure = 1.5
    pc.app.renderer.scene.skyboxIntensity = 1.75
      pc.app.root.findByName("Light").light.color = {
        r: 1.3,
        g: 1.3,
        b: 1.5,
        a: 1,
      };
    }
  }, 2000);
});